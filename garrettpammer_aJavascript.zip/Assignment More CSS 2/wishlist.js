"use strict";

 function addItem(e){ // addItem function
    var li = document.createElement("li"); //create a list for wishlist
    var input = document.getElementById("btnAdd"); //add button by ID
    wishlist.innerHTML = input.value; //input the value of wishlist items
    input.value = alert("Added to Wishlist"); //display confirmation to user
    document.getElementById("wishlistItems").appendChild(li); //document the wishlist items within li wislist
}

// global array to gather wishlist items
var addToWishList = document.querySelector('#add-to-wishlist');
var wishlistItem = document.querySelector('#wishlist-item');
var wishlist = document.querySelector('#wishlist');

// Add item to wishlist
wishlist.innerHTML += '<li><label><input type="button"> ' + wishlistItem.value + '</label></li>';

// Does not add if item is already added
var saved = localStorage.getItem('wishlistItems');

// Save the list to local storage
localStorage.setItem('wishlistItems', wishlist.innerHTML);

// Remove item from wishlist
if (event.target.id === 'wishlist-remove-all') { //target the wishlist remove all list in html
  wishlist.innerHTML = '';
  localStorage.removeItem('wishlistItems'); //remove from local storage
}
